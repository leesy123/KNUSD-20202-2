package example;

public class clock {
	int year;
	int month;
	int day;
	int hour;
	int min;
	
	public clock(int year, int month, int day, int hour, int min) {
		this.year = year;
		this.month = month;
		this.day = day;
		this.hour = hour;
		this.min = min;
	}
}
